/**
 * Created by Tzofia on 20/12/2016.
 */
myApp.controller('loginCtrl',function ($scope) {
    $("#index_banner").removeClass('banner');
    $("#index_banner").addClass('men_banner');
});